// empty function prototype and constants header file

// prototype for the menu function

int menu();
int iffunc();
int forfunc();
int whilefunc(int);
int dowhilefunc(int);
